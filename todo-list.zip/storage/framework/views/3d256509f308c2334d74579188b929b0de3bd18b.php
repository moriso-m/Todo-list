<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success row">
                <a href="#" class="close" data-toggle="alert">&times;</a>
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <h3 class="text-center">Todo List</h3>


            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Task title</th>
                        <th>Task description</th>
                        <th>Due date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($task->title); ?></td>
                            <td><?php echo e($task->description); ?></td>
                            <td><?php echo e($task->date_due); ?></td>
                            <td><?php echo e($task->time_due); ?></td>
                            <td>
                                <?php if($task->completed): ?>
                                    <span class="badge badge-pill badge-success">Completed</span>
                                <?php else: ?>
                                    <span class="badge badge-pill badge-warning">Not completed</span>
                                <?php endif; ?>
                            <td>
                                <a href="tasks/<?php echo e($task->id); ?>/edit" class="btn btn-warning">Edit</a>
                                <a href="#" class="btn btn-danger" id="delete" onclick="deleteTask();">Delete</a>
                                
                                <?php if($task->completed): ?>
                                    <a href="/tasks/completed/<?php echo e($task->id); ?>" class="btn btn-success disabled">
                                        Mark as completed
                                    </a>
                                <?php else: ?>
                                    <a href="/tasks/completed/<?php echo e($task->id); ?>" class="btn btn-success">
                                        Mark as completed
                                    </a>
                                <?php endif; ?>

                                <form action="/tasks/<?php echo e($task->id); ?>" method="post" id="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function deleteTask(){
            let choice = confirm('Are you sure you want to delete the record');
            if(choice){
                document.getElementById('delete-form').submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>