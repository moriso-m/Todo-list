<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors); ?>

        </div>
    <?php endif; ?>
    <form action="/tasks/<?php echo e($task->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="form-group col-md-4 offset-md-4">
            <label for="title">Title:</label>
            <input type="text" name="title" id="" class="form-control" value="<?php echo e($task->title); ?>">
        </div>
        <div class="form-group col-md-4 offset-md-4">
            <label for="description">Description:</label>
            <textarea name="description" id="" class="form-control">
                <?php echo e($task->description); ?>

            </textarea>
        </div>
        <div class="form-row">
            <div class="form-group col-md-2 offset-md-4">
                <label for="date">Due on:</label>
                <input type="date" name="date" id="" class="form-control" value="<?php echo e($task->date); ?>">
            </div>
            <div class="form-group col-md-2">
                <label for="time">Time:</label>
                <input type="time" name="time" id="" class="form-control" value="<?php echo e($task->time); ?>">
            </div>
        </div>
        <div class="form-group col-md-4 offset-md-4 row">
            <input type="checkbox" name="completed" id="" class="form-control col-md-2 offset-md-4"
            <?php if($task->completed): ?>
                checked
            <?php endif; ?>
            >
            <label for="completed" class="col-md-2">Status:</label>
        </div>
        <button type="submit" class="btn btn-outline-success col-md-2 offset-5">
            Edit
        </button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>