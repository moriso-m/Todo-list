<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>
    <form action="/tasks" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group col-md-4 offset-md-4">
            <label for="title">Title:</label>
            <input type="text" name="title" id="" class="form-control">
        </div>
        <div class="form-group col-md-4 offset-md-4">
            <label for="description">Description:</label>
            <textarea name="description" id="" class="form-control"></textarea>
        </div>
        <div class="form-group col-md-4 offset-md-4">
            <label for="date">Due on:</label>
            <input type="date" name="date" id="" class="form-control">
        </div>
        <div class="form-group col-md-4 offset-md-4">
            <label for="time">Time:</label>
            <input type="time" name="time" id="" class="form-control">
        </div>
        <button type="submit" class="btn btn-outline-success col-md-2 offset-5">
            Submit
        </button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>